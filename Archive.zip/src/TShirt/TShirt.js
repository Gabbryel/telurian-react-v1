import React from 'react';

const TShirt = () => {
    return(
        <p>T shirt Telurian</p>
    )
}

export default TShirt;