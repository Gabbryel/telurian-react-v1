const tddImages = [
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056199/TDP/tdp001_isbydn.png',
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056199/TDP/tdp002_filk62.png',
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056199/TDP/tdp003_enlhqs.png',
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056200/TDP/tdp004_ubdp3q.png',
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056202/TDP/tdp005_rjyda9.png',
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056202/TDP/tdp006_jrgmqm.png',
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056202/TDP/tdp007_okiagi.png',
    'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056200/TDP/tdp008_ugxwzs.png'
    ];

    const tceImages = [
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056187/TCE/tce001_i8enik.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056185/TCE/tce020_gegt0b.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056184/TCE/tce019_ftdb5l.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056187/TCE/tce018_mcjtb6.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056186/TCE/tce017_lcj9zs.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056185/TCE/tce016_lhld9q.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056185/TCE/tce015_soagvo.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056187/TCE/tce014_v8w1es.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056189/TCE/tce013_srs7dw.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056190/TCE/tce012_kbpbow.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056188/TCE/tce011_ieaeuh.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056189/TCE/tce010_k0yvzx.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056185/TCE/tce009_tsoh23.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056188/TCE/tce008_oqqnsz.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056188/TCE/tce007_t4kg2l.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056188/TCE/tce006_xx5kgf.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056187/TCE/tce005_uudduy.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056187/TCE/tce004_yu1mmd.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056186/TCE/tce002_e0rymd.png',
        'https://res.cloudinary.com/https-www-zebramusic-net/image/upload/v1609056188/TCE/tce003_wjkbky.png'
    ];

export {tddImages, tceImages};